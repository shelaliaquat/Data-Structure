#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* prev;
    Node* next;
};

int main()
{
    Node* head = new Node{101, nullptr, nullptr};
    Node* second = new Node{102, head, nullptr};
    Node* third = new Node{103, second, nullptr};
    Node* fourth = new Node{104, third, nullptr};
    Node* fifth = new Node{105, fourth, nullptr};

    head->next = second;
    second->next = third;
    third->next = fourth;
    fourth->next = fifth;

    // Add 100 at the start
    Node* newNode = new Node{100, nullptr, head};
    head->prev = newNode;
    head = newNode;

    // Add 1035 after product 103
    Node* middle = new Node{1035, third, third->next};
    third->next->prev = middle;
    third->next = middle;

    // Add 106 at the end
    Node* endNode = new Node{106, fifth, nullptr};
    fifth->next = endNode;

    // Delete the first product
    Node* temp = head;
    head = head->next;
    head->prev = nullptr;
    delete temp;

    // Delete product 104
    temp = head;
    while (temp != nullptr && temp->data != 104)
    {
        temp = temp->next;
    }
    if (temp != nullptr)
    {
        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;
        delete temp;
    }

    // Delete the last product
    temp = head;
    while (temp->next != nullptr)
    {
        temp = temp->next;
    }
    temp->prev->next = nullptr;
    delete temp;

    // Display final list
    temp = head;
    cout << "Final Doubly Linked List:" << endl;
    while (temp != nullptr)
    {
        cout << temp->data;
        if (temp->next != nullptr)
            cout << " <-> ";
        temp = temp->next;
    }

    cout << endl;
    return 0;
}
