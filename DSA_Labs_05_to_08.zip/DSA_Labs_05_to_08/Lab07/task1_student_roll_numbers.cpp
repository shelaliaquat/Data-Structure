#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* prev;
    Node* next;
};

int main()
{
    Node* head = new Node{10, nullptr, nullptr};
    Node* second = new Node{20, head, nullptr};
    Node* third = new Node{30, second, nullptr};
    Node* fourth = new Node{40, third, nullptr};
    Node* fifth = new Node{50, fourth, nullptr};

    head->next = second;
    second->next = third;
    third->next = fourth;
    fourth->next = fifth;

    // Add 5 at the start
    Node* newNode = new Node{5, nullptr, head};
    head->prev = newNode;
    head = newNode;

    // Add 25 after 20
    Node* middle = new Node{25, second, second->next};
    second->next->prev = middle;
    second->next = middle;

    // Add 60 at the end
    Node* endNode = new Node{60, fifth, nullptr};
    fifth->next = endNode;

    // Display final list
    Node* temp = head;

    cout << "Final Doubly Linked List: " << endl;

    while (temp != nullptr)
    {
        cout << temp->data;
        if (temp->next != nullptr)
            cout << " <-> ";
        temp = temp->next;
    }

    cout << endl;
    return 0;
}
