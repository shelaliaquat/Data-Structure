# DSA Labs 05–08

Individual C++ source files organized by lab:

- Lab05: Singly linked list insertion operations.
- Lab06: Singly linked list deletion operations.
- Lab07: Doubly linked list operations.
- Lab08: Selection sort, bubble sort, insertion sort, and binary search menu.

Each task is saved as a separate `.cpp` file.
