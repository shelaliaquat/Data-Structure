#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = NULL;
    }
};

class LinkedList {
public:
    Node* head;

    LinkedList() {
        head = NULL;
    }

    void insertAtEnd(int value) {
        Node* newNode = new Node(value);

        if (head == NULL) {
            head = newNode;
            return;
        }

        Node* temp = head;

        while (temp->next != NULL) {
            temp = temp->next;
        }

        temp->next = newNode;
    }

    void deleteByValue(int value) {

        if (head == NULL) {
            cout << "Value not found" << endl;
            return;
        }

        if (head->data == value) {
            Node* deleteNode = head;
            head = head->next;
            delete deleteNode;
            return;
        }

        Node* temp = head;

        while (temp->next != NULL) {

            if (temp->next->data == value) {

                Node* deleteNode = temp->next;

                temp->next = deleteNode->next;

                delete deleteNode;

                return;
            }

            temp = temp->next;
        }

        cout << "Value not found" << endl;
    }

    void display() {
        Node* temp = head;

        while (temp != NULL) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }

        cout << "NULL" << endl;
    }
};

int main()
{
    LinkedList list;

    list.insertAtEnd(10);
    list.insertAtEnd(20);
    list.insertAtEnd(30);
    list.insertAtEnd(40);
    list.insertAtEnd(50);

    list.deleteByValue(10);
    list.display();

    list.deleteByValue(30);
    list.display();

    list.deleteByValue(50);
    list.display();

    list.deleteByValue(100);

    return 0;
}
