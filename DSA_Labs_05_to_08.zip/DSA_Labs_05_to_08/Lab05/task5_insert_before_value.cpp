#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

int main()
{
    Node* head = new Node;
    Node* second = new Node;
    Node* third = new Node;

    head->data = 10;
    second->data = 20;
    third->data = 30;

    head->next = second;
    second->next = third;
    third->next = nullptr;

    int target, newValue;

    cout << "Enter value before which you want to insert: ";
    cin >> target;

    cout << "Enter new value: ";
    cin >> newValue;

    Node* newNode = new Node;
    newNode->data = newValue;

    // If target is the first node
    if(head != nullptr && head->data == target)
    {
        newNode->next = head;
        head = newNode;
    }
    else
    {
        Node* prev = nullptr;
        Node* temp = head;

        while(temp != nullptr && temp->data != target)
        {
            prev = temp;
            temp = temp->next;
        }

        if(temp == nullptr)
        {
            cout << "Value not found.";
        }
        else
        {
            newNode->next = temp;
            prev->next = newNode;
        }
    }

    cout << "Linked List: ";

    Node* temp = head;

    while(temp != nullptr)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    return 0;
}
