#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

Node* head = nullptr;

void insertStart(int value)
{
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = head;
    head = newNode;
}

void insertEnd(int value)
{
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = nullptr;

    if(head == nullptr)
    {
        head = newNode;
        return;
    }

    Node* temp = head;

    while(temp->next != nullptr)
    {
        temp = temp->next;
    }

    temp->next = newNode;
}

void insertMiddle(int afterValue, int value)
{
    Node* temp = head;

    while(temp != nullptr && temp->data != afterValue)
    {
        temp = temp->next;
    }

    if(temp == nullptr)
    {
        cout << "Value not found.";
        return;
    }

    Node* newNode = new Node;
    newNode->data = value;

    newNode->next = temp->next;
    temp->next = newNode;
}

void display()
{
    Node* temp = head;

    while(temp != nullptr)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    int choice, value, afterValue;

    do
    {
        cout << "\n1. Insert at Start";
        cout << "\n2. Insert at End";
        cout << "\n3. Insert in Middle";
        cout << "\n4. Display List";
        cout << "\n5. Exit";
        cout << "\nEnter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << "Enter value: ";
                cin >> value;
                insertStart(value);
                break;

            case 2:
                cout << "Enter value: ";
                cin >> value;
                insertEnd(value);
                break;

            case 3:
                cout << "Insert after which value: ";
                cin >> afterValue;

                cout << "Enter new value: ";
                cin >> value;

                insertMiddle(afterValue, value);
                break;

            case 4:
                display();
                break;

            case 5:
                cout << "Program ended.";
                break;

            default:
                cout << "Invalid choice.";
        }
    } while(choice != 5);

    return 0;
}
