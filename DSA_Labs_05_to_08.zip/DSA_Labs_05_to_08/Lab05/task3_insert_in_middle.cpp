#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

int main()
{
    int n, afterValue, newValue;

    cout << "Enter number of nodes: ";
    cin >> n;

    Node* head = nullptr;
    Node* tail = nullptr;

    for(int i = 0; i < n; i++)
    {
        Node* newNode = new Node;
        cin >> newNode->data;
        newNode->next = nullptr;

        if(head == nullptr)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
    }

    cout << "Enter value after which you want to insert: ";
    cin >> afterValue;

    cout << "Enter new value: ";
    cin >> newValue;

    Node* temp = head;

    while(temp != nullptr && temp->data != afterValue)
    {
        temp = temp->next;
    }

    if(temp == nullptr)
    {
        cout << "Value not found.";
    }
    else
    {
        Node* newNode = new Node;
        newNode->data = newValue;

        newNode->next = temp->next;
        temp->next = newNode;

        cout << "Linked List: ";

        temp = head;

        while(temp != nullptr)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
    }

    return 0;
}
