#include <iostream>
#include <vector>
using namespace std;

int main() {
    int V = 4;

    vector<int> adj[4];

    // Simple directed graph
    adj[0].push_back(1);
    adj[0].push_back(2);
    adj[1].push_back(2);
    adj[2].push_back(3);

    // Display graph
    cout << "Classroom Names Graph:\n";

    for (int i = 0; i < V; i++) {
        cout << "Person " << char('A' + i) << " -> ";

        for (int neighbor : adj[i]) {
            cout << char('A' + neighbor) << " ";
        }

        cout << endl;
    }

    return 0;
}
