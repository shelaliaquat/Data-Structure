#include <iostream>
#include <vector>
using namespace std;

class Graph {
    int V;
    vector<pair<int, int>> adj[10];

public:
    Graph(int vertices) {
        V = vertices;
    }

    // Add directed weighted edge
    void addEdge(int u, int v, int weight) {
        adj[u].push_back({v, weight});
    }

    // Display graph
    void display() {
        cout << "\nDirected Weighted Graph:\n";

        for (int i = 0; i < V; i++) {
            cout << i << " -> ";

            for (auto edge : adj[i]) {
                cout << "(" << edge.first
                     << ", weight = " << edge.second
                     << ") ";
            }

            cout << endl;
        }
    }
};

int main() {
    Graph g(5);

    // Adding directed weighted edges
    g.addEdge(0, 1, 10);
    g.addEdge(0, 2, 20);
    g.addEdge(1, 2, 30);
    g.addEdge(2, 3, 40);
    g.addEdge(3, 4, 50);

    g.display();

    return 0;
}
