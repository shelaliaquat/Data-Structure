# DSA Labs 09–13

Individual C++ source files organized by lab.

- Lab09: Stack using array.
- Lab10: Stack applications using linked lists.
- Lab11: Array queue, linked-list queue, circular queue, and queue reversal.
- Lab12: Tree traversals and BST insertion.
- Lab13: Directed weighted graph and classroom-names graph.

Only the tasks supplied in the message are included:
- Lab09: Task 3
- Lab10: Tasks 1–3
- Lab11: Tasks 1–4
- Lab12: Tasks 1–2
- Lab13: Tasks 1 and 3

Lab09 Tasks 1–2 and Lab13 Task 2 were not included because their code was not provided.
