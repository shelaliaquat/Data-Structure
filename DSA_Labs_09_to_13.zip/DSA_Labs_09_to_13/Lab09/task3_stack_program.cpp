#include <iostream>
using namespace std;

#define MAX 5

class Stack {
    int arr[MAX];
    int top;

public:
    Stack() {
        top = -1;
    }

    void push(int x) {
        if (top == MAX - 1) {
            cout << "Stack overflow!" << endl;
        }
        else {
            arr[++top] = x;
            cout << x << " pushed into stack" << endl;
        }
    }

    void pop() {
        if (top == -1) {
            cout << "Stack underflow!" << endl;
        }
        else {
            cout << "Popped: " << arr[top--] << endl;
        }
    }

    // Returns the number of steps from the top, or -1 if not found
    int search(int x) {
        int steps = 1;

        for (int i = top; i >= 0; i--) {
            if (arr[i] == x) {
                return steps;
            }
            steps++;
        }

        return -1;
    }
};

int main()
{
    Stack s;
    int num;

    cout << "Enter 5 integers:" << endl;
    for (int i = 0; i < MAX; i++) {
        cin >> num;
        s.push(num);
    }

    cout << "\nTrying to push sixth value:" << endl;
    s.push(60);

    cout << "\nSearching values:" << endl;
    cout << "Search 30: " << s.search(30) << endl;
    cout << "Search 90: " << s.search(90) << endl;

    cout << "\nPopping all elements:" << endl;
    for (int i = 0; i < MAX; i++) {
        s.pop();
    }

    cout << "\nTrying to pop again:" << endl;
    s.pop();

    return 0;
}
