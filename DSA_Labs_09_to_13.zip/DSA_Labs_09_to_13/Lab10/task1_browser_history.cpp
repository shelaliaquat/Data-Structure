#include <iostream>
#include <string>
using namespace std;

struct Node
{
    string data;
    Node* next;
};

Node* top = NULL;

void push(string page)
{
    Node* newNode = new Node;
    newNode->data = page;
    newNode->next = top;
    top = newNode;
}

void pop()
{
    if (top == NULL)
    {
        cout << "Cannot go back" << endl;
        return;
    }

    if (top->next == NULL)
    {
        cout << "Cannot go back" << endl;
        return;
    }

    Node* temp = top;
    top = top->next;
    delete temp;

    cout << "Current page: " << top->data << endl;
}

void display()
{
    Node* current = top;

    while (current != NULL)
    {
        cout << current->data << endl;
        current = current->next;
    }
}

int main()
{
    push("home");
    push("news");
    push("sports");

    cout << "History:" << endl;
    display();

    cout << endl << "Back:" << endl;
    pop();
    pop();
    pop();

    return 0;
}
