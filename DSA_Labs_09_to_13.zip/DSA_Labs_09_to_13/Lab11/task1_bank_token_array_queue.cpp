#include <iostream>
using namespace std;

#define SIZE 6

int queue[SIZE];
int front = -1, rear = -1;
int token = 1;

void issueToken()
{
    if (rear == SIZE - 1)
    {
        cout << "\nWaiting room is FULL! No more tokens can be issued.\n";
    }
    else
    {
        if (front == -1)
            front = 0;

        queue[++rear] = token++;

        cout << "\nToken issued successfully!\n";
        cout << "Your token number is: " << queue[rear] << endl;
    }
}

void serveCustomer()
{
    if (front == -1 || front > rear)
    {
        cout << "\nNobody is waiting. Queue is EMPTY!\n";
    }
    else
    {
        cout << "\nServing token number: " << queue[front] << endl;
        front++;
    }
}

void showWaiting()
{
    if (front == -1 || front > rear)
    {
        cout << "\nNobody is waiting. Queue is EMPTY!\n";
    }
    else
    {
        cout << "\nWaiting customers (token numbers): ";
        for (int i = front; i <= rear; i++)
        {
            cout << queue[i] << " ";
        }
        cout << endl;
    }
}

int main()
{
    int choice;

    do
    {
        cout << "\n===== BANK TOKEN SYSTEM =====\n";
        cout << "1. Issue Token (Enqueue)\n";
        cout << "2. Serve Customer (Dequeue)\n";
        cout << "3. Show Waiting Customers\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                issueToken();
                break;
            case 2:
                serveCustomer();
                break;
            case 3:
                showWaiting();
                break;
            case 4:
                cout << "\nExiting program...\n";
                break;
            default:
                cout << "\nInvalid choice!\n";
        }
    } while (choice != 4);

    return 0;
}
