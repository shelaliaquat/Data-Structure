#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

Node* front = NULL;
Node* rear = NULL;

void enqueue(int value)
{
    Node* newNode = new Node;

    newNode->data = value;
    newNode->next = NULL;

    if (front == NULL)
    {
        front = rear = newNode;
    }
    else
    {
        rear->next = newNode;
        rear = newNode;
    }

    cout << value << " inserted into queue.\n";
}

void dequeue()
{
    if (front == NULL)
    {
        cout << "Queue is EMPTY!\n";
        return;
    }

    Node* temp = front;
    cout << temp->data << " removed from queue.\n";

    front = front->next;

    if (front == NULL)
        rear = NULL;

    delete temp;
}

void display()
{
    if (front == NULL)
    {
        cout << "Queue is EMPTY!\n";
        return;
    }

    Node* temp = front;
    cout << "Queue: ";

    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

// Returns the number of nodes in the queue
int countNodes()
{
    int count = 0;
    Node* temp = front;

    while (temp != NULL)
    {
        count++;
        temp = temp->next;
    }

    return count;
}

// Shows the value stored in the last node
void displayRear()
{
    if (rear == NULL)
        cout << "Queue is EMPTY!\n";
    else
        cout << "Rear value: " << rear->data << endl;
}

// Removes all nodes and frees the memory
void clearQueue()
{
    while (front != NULL)
    {
        Node* temp = front;
        front = front->next;
        delete temp;
    }

    rear = NULL;
    cout << "Queue cleared.\n";
}

int main()
{
    int choice, value;

    do
    {
        cout << "\n===== LINKED LIST QUEUE =====\n";
        cout << "1. Enqueue (Insert)\n";
        cout << "2. Dequeue (Remove)\n";
        cout << "3. Display Queue\n";
        cout << "4. Count Nodes\n";
        cout << "5. Display Rear\n";
        cout << "6. Clear Queue\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                cout << "Enter value: ";
                cin >> value;
                enqueue(value);
                break;
            case 2:
                dequeue();
                break;
            case 3:
                display();
                break;
            case 4:
                cout << "Total nodes: " << countNodes() << endl;
                break;
            case 5:
                displayRear();
                break;
            case 6:
                clearQueue();
                break;
            case 7:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice!\n";
        }
    } while (choice != 7);

    return 0;
}
