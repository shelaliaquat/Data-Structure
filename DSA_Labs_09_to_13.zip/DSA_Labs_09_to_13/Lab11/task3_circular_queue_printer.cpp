#include <iostream>
using namespace std;

#define SIZE 4

int queue[SIZE];
int front = -1;
int rear = -1;
int count = 0;

void enqueue(int value)
{
    if (count == SIZE)
    {
        cout << "Queue is FULL! Cannot insert "
             << value << endl;
        return;
    }

    if (count == 0)
    {
        front = 0;
    }

    rear = (rear + 1) % SIZE;
    queue[rear] = value;
    count++;

    cout << "Inserted: " << value << endl;
}

void dequeue()
{
    if (count == 0)
    {
        cout << "Queue is EMPTY!" << endl;
        return;
    }

    cout << "Removed: " << queue[front] << endl;

    front = (front + 1) % SIZE;
    count--;
}

void display()
{
    cout << "Front = " << front << " | Rear = " << rear
         << " | Count = " << count << endl;

    cout << "Queue: ";
    for (int i = 0, idx = front; i < count; i++)
    {
        cout << queue[idx] << " ";
        idx = (idx + 1) % SIZE;
    }
    cout << endl << endl;
}

int main()
{
    cout << "Step 1: enqueue(101)" << endl;
    enqueue(101);
    display();

    cout << "Step 2: enqueue(102)" << endl;
    enqueue(102);
    display();

    cout << "Step 3: enqueue(103)" << endl;
    enqueue(103);
    display();

    cout << "Step 4: enqueue(104)" << endl;
    enqueue(104);
    display();

    cout << "Step 5: enqueue(105)" << endl;
    enqueue(105);
    display();

    cout << "Step 6: dequeue()" << endl;
    dequeue();
    display();

    cout << "Step 7: dequeue()" << endl;
    dequeue();
    display();

    cout << "Step 8: enqueue(105)" << endl;
    enqueue(105);
    display();

    cout << "Step 9: enqueue(106)" << endl;
    enqueue(106);
    display();

    return 0;
}
