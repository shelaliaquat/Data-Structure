#include <stdio.h>
#include <stdlib.h>

struct Product {
    char name[50];
    int code;
    float price;
};

int main() {
    int n;

    printf("Enter number of products: ");
    scanf("%d", &n);

    struct Product *products =
        (struct Product *)malloc(n * sizeof(struct Product));

    if (products == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        printf("\nEnter details for product %d:\n", i + 1);

        printf("Name: ");
        scanf("%s", products[i].name);

        printf("Code: ");
        scanf("%d", &products[i].code);

        printf("Price: ");
        scanf("%f", &products[i].price);
    }

    printf("\n------- Product Details -------\n");

    for (int i = 0; i < n; i++) {
        printf("\nProduct %d\n", i + 1);
        printf("Name  : %s\n", products[i].name);
        printf("Code  : %d\n", products[i].code);
        printf("Price : %.2f\n", products[i].price);
    }

    free(products);

    return 0;
}
