# DSA Labs 01–04

Individual C++ source files organized by lab:

- Lab01: Student performance, bank account using pointers, employee salary structure.
- Lab02: Maximum of three using pointers, reverse array using pointers, link three nodes.
- Lab03: Dynamic memory for products, dynamic character, dynamic 2D array.
- Lab04: Array insertion, deletion, linear search, and binary search.

Each task is saved as a separate `.cpp` file.
