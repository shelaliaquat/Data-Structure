#include <iostream>
using namespace std;

int main() {
    int marks[10];
    int sum = 0;
    int highest, lowest;
    int passed = 0, failed = 0;

    cout << "Enter marks of 10 students:" << endl;

    for (int i = 0; i < 10; i++) {
        cout << "Student " << i + 1 << ": ";
        cin >> marks[i];
        sum += marks[i];

        if (marks[i] >= 50)
            passed++;
        else
            failed++;
    }

    highest = lowest = marks[0];

    for (int i = 1; i < 10; i++) {
        if (marks[i] > highest)
            highest = marks[i];

        if (marks[i] < lowest)
            lowest = marks[i];
    }

    double average = sum / 10.0;

    cout << "\n--- Student Performance ---\n";

    cout << "All Marks: ";
    for (int i = 0; i < 10; i++) {
        cout << marks[i] << " ";
    }

    cout << "\nAverage Marks: " << average;
    cout << "\nHighest Marks: " << highest;
    cout << "\nLowest Marks: " << lowest;
    cout << "\nPassed Students: " << passed;
    cout << "\nFailed Students: " << failed;

    return 0;
}
