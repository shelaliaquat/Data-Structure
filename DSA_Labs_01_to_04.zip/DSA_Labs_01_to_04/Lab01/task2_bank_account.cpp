#include <iostream>
using namespace std;

int main() {
    double balance, deposit, withdrawal;

    cout << "Enter initial balance: ";
    cin >> balance;

    cout << "Enter deposit amount: ";
    cin >> deposit;

    double *ptr = &balance;

    *ptr = *ptr + deposit;

    cout << "Balance after deposit: Rs. " << balance << endl;

    cout << "Enter withdrawal amount: ";
    cin >> withdrawal;

    if (withdrawal > *ptr) {
        cout << "Insufficient balance!" << endl;
    }
    else {
        *ptr = *ptr - withdrawal;
        cout << "Balance after withdrawal: Rs. " << balance << endl;
    }

    return 0;
}
