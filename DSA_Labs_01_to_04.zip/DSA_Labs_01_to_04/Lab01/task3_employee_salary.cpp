#include <iostream>
#include <string>
using namespace std;

struct Employee {
    int id;
    string name;
    double basicSalary;
    double allowance;
};

int main() {
    Employee emp;

    cout << "Enter Employee ID: ";
    cin >> emp.id;

    cin.ignore();

    cout << "Enter Employee Name: ";
    getline(cin, emp.name);

    cout << "Enter Basic Salary: ";
    cin >> emp.basicSalary;

    cout << "Enter Allowance: ";
    cin >> emp.allowance;

    double grossSalary = emp.basicSalary + emp.allowance;
    double tax;

    if (grossSalary > 100000) {
        tax = grossSalary * 0.05;
    }
    else {
        tax = grossSalary * 0.02;
    }

    double finalSalary = grossSalary - tax;

    cout << "--- Employee Salary Details ---\n";
    cout << "Employee ID: " << emp.id << endl;
    cout << "Employee Name: " << emp.name << endl;
    cout << "Basic Salary: Rs. " << emp.basicSalary << endl;
    cout << "Allowance: Rs. " << emp.allowance << endl;
    cout << "Gross Salary: Rs. " << grossSalary << endl;
    cout << "Tax: Rs. " << tax << endl;
    cout << "Final Salary: Rs. " << finalSalary << endl;

    return 0;
}
